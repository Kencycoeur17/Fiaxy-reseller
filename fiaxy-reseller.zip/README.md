# FiaXY Reseller MVP

Interface revendeur minimaliste pour gérer les cartes Visa FiaXY.

## Fonctionnalités
- Connexion sécurisée (nom d'utilisateur + mot de passe)
- Tableau de bord de base
- Design responsive Bootstrap

## Utilisation
- Déployer sur GitHub Pages
- Ajouter Firebase ou un backend PHP selon besoin

## Licence
MIT License
